from p5 import *

# constantes
CARTAS = "A23456789XJQK"
NAIPES = "OPCE"
CARTA_LARGURA = 64
CARTA_ALTURA = 91

# variáveis globais
baralho = None
img = None


# cria imagens do baralho
def cria_baralho():
    baralho = {}
    for naipe in NAIPES:
        for carta in CARTAS:
            chave = carta+naipe
            imagem = load_image("baralho/" + carta + naipe + ".jpg")
            # WINDOWS "baralho\\"
            baralho[chave]=imagem
    return baralho


def setup():
    global img, baralho
    size(1000, 800)

    # cria baralho com imagens das cartas
    baralho = cria_baralho()

def draw():
    global img
    background("green")

    # exemplos
    image(baralho["KO"], (0, 0))
    image(baralho["AE"], (100, 80))
    image(baralho["4P"], (100, 180))
    image(baralho["XE"], (250, 80)) # a carta 10 é representada pelo "X"

    # desenhar todo o baralho
    x = 0
    y = 300
    for naipe in NAIPES:
        for carta in CARTAS:
            image(baralho[carta+naipe], (x,y))
            x += CARTA_LARGURA
        x = 0
        y += CARTA_ALTURA


if __name__ == '__main__':
    run()
